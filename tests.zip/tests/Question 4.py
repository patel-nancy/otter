OK_FORMAT = True

test = {'name': 'Question 4', 'points': 1, 'suites': [{'cases': [{'code': '>>> q4 == 2\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
