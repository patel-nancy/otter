OK_FORMAT = True

test = {'name': 'Question 3', 'points': 2, 'suites': [{'cases': [{'code': '>>> b == 1\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
