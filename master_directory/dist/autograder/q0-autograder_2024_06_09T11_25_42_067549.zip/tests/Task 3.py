OK_FORMAT = True

test = {   'name': 'Task 3',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': ">>> '0' in counts and counts['0'] == 468\nTrue",
                                       'failure_message': 'EXPECTED simpleCircuit TO BE RUN 468 TIMES',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 10}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
